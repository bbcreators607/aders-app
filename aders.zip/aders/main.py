from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
import json, os

USERS_FILE = "users.json"
ADS_FILE = "ads.json"

def load_data(file):
    if os.path.exists(file):
        with open(file, "r") as f:
            return json.load(f)
    return []

def save_data(file, data):
    with open(file, "w") as f:
        json.dump(data, f)

users = load_data(USERS_FILE)
ads = load_data(ADS_FILE)

current_user = ""

# ---------- LOGIN ---------- #
class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        layout = BoxLayout(orientation="vertical", padding=20, spacing=10)

        self.username = TextInput(hint_text="Username")
        self.password = TextInput(hint_text="Password", password=True)

        layout.add_widget(Label(text="Aders", font_size=30))
        layout.add_widget(self.username)
        layout.add_widget(self.password)

        layout.add_widget(Button(text="Login", on_press=self.login))
        layout.add_widget(Button(text="Signup", on_press=self.signup))

        self.add_widget(layout)

    def login(self, instance):
        global current_user
        u = self.username.text
        p = self.password.text

        for user in users:
            if user["username"] == u and user["password"] == p:
                current_user = u
                self.manager.current = "home"
                return

    def signup(self, instance):
        u = self.username.text
        p = self.password.text

        if not u or not p:
            return

        for user in users:
            if user["username"] == u:
                return

        users.append({"username": u, "password": p})
        save_data(USERS_FILE, users)

# ---------- HOME ---------- #
class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.layout = BoxLayout(orientation="vertical")

        self.search = TextInput(hint_text="Search...")
        self.search.bind(text=self.update_ads)

        self.layout.add_widget(self.search)

        self.scroll = ScrollView()
        self.ads_layout = GridLayout(cols=1, size_hint_y=None)
        self.ads_layout.bind(minimum_height=self.ads_layout.setter('height'))

        self.scroll.add_widget(self.ads_layout)
        self.layout.add_widget(self.scroll)

        btns = BoxLayout(size_hint_y=None, height=50)
        btns.add_widget(Button(text="Post Ad", on_press=self.go_post))
        btns.add_widget(Button(text="Logout", on_press=self.logout))

        self.layout.add_widget(btns)

        self.add_widget(self.layout)

    def on_enter(self):
        self.update_ads()

    def update_ads(self, *args):
        self.ads_layout.clear_widgets()
        query = self.search.text.lower()

        for ad in ads:
            if query not in ad["title"].lower() and query not in ad["desc"].lower():
                continue

            box = BoxLayout(orientation="vertical", size_hint_y=None, height=120)

            box.add_widget(Label(text=ad["title"]))
            box.add_widget(Label(text=ad["desc"]))

            like_btn = Button(text=f"❤️ {ad.get('likes',0)}")
            like_btn.bind(on_press=lambda x, a=ad: self.like_ad(a))

            box.add_widget(like_btn)
            box.add_widget(Label(text=f"By {ad['user']}"))

            self.ads_layout.add_widget(box)

    def like_ad(self, ad):
        ad["likes"] = ad.get("likes", 0) + 1
        save_data(ADS_FILE, ads)
        self.update_ads()

    def go_post(self, instance):
        self.manager.current = "post"

    def logout(self, instance):
        self.manager.current = "login"

# ---------- POST ---------- #
class PostScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        layout = BoxLayout(orientation="vertical", padding=20, spacing=10)

        self.title = TextInput(hint_text="Title")
        self.desc = TextInput(hint_text="Description")

        layout.add_widget(Label(text="Create Ad", font_size=25))
        layout.add_widget(self.title)
        layout.add_widget(self.desc)

        layout.add_widget(Button(text="Post", on_press=self.post))
        layout.add_widget(Button(text="Back", on_press=self.back))

        self.add_widget(layout)

    def post(self, instance):
        if self.title.text and self.desc.text:
            ads.append({
                "title": self.title.text,
                "desc": self.desc.text,
                "user": current_user,
                "likes": 0
            })
            save_data(ADS_FILE, ads)
            self.manager.current = "home"

    def back(self, instance):
        self.manager.current = "home"

# ---------- APP ---------- #
class AdersApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(PostScreen(name="post"))
        return sm

AdersApp().run()